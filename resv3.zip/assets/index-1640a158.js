import{s as e}from"./index-602e87f8.js";const r=e(),t=e=>{let t=`./theme-${r.appTheme}/image/${e}`;return new URL(t,import.meta.url).href};export{t as g};
