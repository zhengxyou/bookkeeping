import{b as o}from"./function-call-8352b75c.js";import{M as i}from"./index-0ce16e7f.js";i(o);
