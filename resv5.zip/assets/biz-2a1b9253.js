import{_ as r}from"./ai-container-9f6c5766.js";import{_ as n,b as o,c as s}from"./index-0ce16e7f.js";const t=n({},[["render",function(n,t){const a=r;return o(),s(a)}]]);export{t as default};
