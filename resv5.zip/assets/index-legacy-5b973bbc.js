System.register(["./function-call-legacy-91bd57e8.js","./index-legacy-1ef46843.js"],(function(e,t){"use strict";var c,n;return{setters:[e=>{c=e.b},e=>{n=e.M}],execute:function(){n(c)}}}));
