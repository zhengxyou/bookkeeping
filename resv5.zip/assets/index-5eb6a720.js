import{s}from"./index-58e0f6aa.js";import{M as o}from"./index-0ce16e7f.js";const r=o(s);export{r as C};
