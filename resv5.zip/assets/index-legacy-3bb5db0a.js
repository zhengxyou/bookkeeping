System.register(["./index-legacy-39adca16.js","./index-legacy-1ef46843.js"],(function(e,t){"use strict";var s,n;return{setters:[e=>{s=e.s},e=>{n=e.M}],execute:function(){e("C",n(s))}}}));
