import{s}from"./index-10d81a90.js";import{M as o}from"./index-a237545b.js";const r=o(s);export{r as C};
