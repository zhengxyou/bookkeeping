import{aC as n}from"./index-a237545b.js";let o=0;function t(){const t=n(),{name:e="unknown"}=(null==t?void 0:t.type)||{};return`${e}-${++o}`}export{t as u};
