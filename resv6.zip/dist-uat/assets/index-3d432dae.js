import{b as o}from"./function-call-c1531aad.js";import{M as i}from"./index-a237545b.js";i(o);
