System.register(["./function-call-legacy-b9344a80.js","./index-legacy-9fecaa98.js"],(function(e,t){"use strict";var c,n;return{setters:[e=>{c=e.b},e=>{n=e.M}],execute:function(){n(c)}}}));
