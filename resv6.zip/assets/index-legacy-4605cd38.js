System.register(["./index-legacy-1c20505e.js","./index-legacy-9fecaa98.js"],(function(e,t){"use strict";var s,n;return{setters:[e=>{s=e.s},e=>{n=e.M}],execute:function(){e("C",n(s))}}}));
