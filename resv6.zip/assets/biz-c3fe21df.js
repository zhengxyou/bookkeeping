import{_ as r}from"./ai-container-6a2937ab.js";import{_ as n,b as o,c as s}from"./index-01ae7a38.js";const t=n({},[["render",function(n,t){const a=r;return o(),s(a)}]]);export{t as default};
