System.register(["./index-legacy-60e6b1e8.js","./index-legacy-8afc652a.js"],(function(e,t){"use strict";var s,n;return{setters:[e=>{s=e.s},e=>{n=e.M}],execute:function(){e("C",n(s))}}}));
