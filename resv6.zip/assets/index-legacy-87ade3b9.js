System.register(["./index-legacy-d112b652.js","./index-legacy-cf09e110.js"],(function(e,t){"use strict";var s,n;return{setters:[e=>{s=e.s},e=>{n=e.M}],execute:function(){e("C",n(s))}}}));
