System.register(["./function-call-legacy-2ebed202.js","./index-legacy-8afc652a.js"],(function(e,t){"use strict";var c,n;return{setters:[e=>{c=e.b},e=>{n=e.M}],execute:function(){n(c)}}}));
