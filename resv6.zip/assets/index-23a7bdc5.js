import{s}from"./index-326ee5a5.js";import{M as o}from"./index-01ae7a38.js";const r=o(s);export{r as C};
