import{aC as n}from"./index-01ae7a38.js";let o=0;function t(){const t=n(),{name:e="unknown"}=(null==t?void 0:t.type)||{};return`${e}-${++o}`}export{t as u};
