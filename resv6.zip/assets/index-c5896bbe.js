import{s}from"./index-62d19628.js";import{M as o}from"./index-66ddf4c3.js";const r=o(s);export{r as C};
