import{b as o}from"./function-call-6c9b3bc3.js";import{M as i}from"./index-66ddf4c3.js";i(o);
