System.register(["./function-call-legacy-d3e0854e.js","./index-legacy-cf09e110.js"],(function(e,t){"use strict";var c,n;return{setters:[e=>{c=e.b},e=>{n=e.M}],execute:function(){n(c)}}}));
