import{b as o}from"./function-call-ed4b8fb6.js";import{M as i}from"./index-01ae7a38.js";i(o);
